// basl_Attrib.cpp
//

#include "basl_Attrib.h"
#define LZZ_INLINE inline
namespace basl
{
  Attrib::Attrib ()
    {}
}
namespace basl
{
  Attrib::~ Attrib ()
    {}
}
#undef LZZ_INLINE
