// basl_Attrib.h
//

#ifndef LZZ_basl_Attrib_h
#define LZZ_basl_Attrib_h
#define LZZ_INLINE inline
namespace basl
{
  class Attrib
  {
  public:
    Attrib ();
    virtual ~ Attrib ();
  };
}
#undef LZZ_INLINE
#endif
