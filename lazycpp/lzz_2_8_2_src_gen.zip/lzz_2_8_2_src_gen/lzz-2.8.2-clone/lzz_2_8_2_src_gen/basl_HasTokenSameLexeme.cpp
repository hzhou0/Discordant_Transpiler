// basl_HasTokenSameLexeme.cpp
//

#include "basl_HasTokenSameLexeme.h"
#ifndef LZZ_ENABLE_INLINE
#include "basl_HasTokenSameLexeme.inl"
#endif
#define LZZ_INLINE inline
namespace basl
{
  HasTokenSameLexeme::~ HasTokenSameLexeme ()
              {}
}
#undef LZZ_INLINE
