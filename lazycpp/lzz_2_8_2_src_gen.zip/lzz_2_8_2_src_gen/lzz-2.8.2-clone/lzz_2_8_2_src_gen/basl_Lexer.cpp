// basl_Lexer.cpp
//

#include "basl_Lexer.h"
#define LZZ_INLINE inline
namespace basl
{
  Lexer::~ Lexer ()
                       {}
}
#undef LZZ_INLINE
