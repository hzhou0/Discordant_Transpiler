// basl_NontermInfo.cpp
//

#include "basl_NontermInfo.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
