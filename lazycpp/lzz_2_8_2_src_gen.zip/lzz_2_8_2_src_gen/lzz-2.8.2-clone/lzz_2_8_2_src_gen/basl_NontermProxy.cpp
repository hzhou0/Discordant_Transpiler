// basl_NontermProxy.cpp
//

#include "basl_NontermProxy.h"
#ifndef LZZ_ENABLE_INLINE
#include "basl_NontermProxy.inl"
#endif
// basil
#include "basl_Nonterm.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
