// basl_Parser.cpp
//

#include "basl_Parser.h"
#define LZZ_INLINE inline
namespace basl
{
  Parser::~ Parser ()
                        {}
}
#undef LZZ_INLINE
