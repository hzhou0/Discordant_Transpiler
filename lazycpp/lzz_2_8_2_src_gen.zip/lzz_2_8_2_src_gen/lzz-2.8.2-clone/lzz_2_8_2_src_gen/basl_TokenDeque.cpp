// basl_TokenDeque.cpp
//

#include "basl_TokenDeque.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
