// basl_TokenFlags.cpp
//

#include "basl_TokenFlags.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
