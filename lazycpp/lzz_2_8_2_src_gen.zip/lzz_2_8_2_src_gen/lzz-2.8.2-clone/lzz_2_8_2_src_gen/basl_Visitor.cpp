// basl_Visitor.cpp
//

#include "basl_Visitor.h"
#define LZZ_INLINE inline
namespace basl
{
  Visitor::Visitor ()
    {}
}
namespace basl
{
  Visitor::~ Visitor ()
    {}
}
#undef LZZ_INLINE
