// conf_LzzVersion.cpp
//

#include "conf_LzzVersion.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
