// gram_DclSpecFlags.cpp
//

#include "gram_DclSpecFlags.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
