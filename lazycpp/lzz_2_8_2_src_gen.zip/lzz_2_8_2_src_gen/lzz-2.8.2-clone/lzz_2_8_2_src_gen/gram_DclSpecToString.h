// gram_DclSpecToString.h
//

#ifndef LZZ_gram_DclSpecToString_h
#define LZZ_gram_DclSpecToString_h
#define LZZ_INLINE inline
namespace gram
{
  char const * dclSpecToString (int flag);
}
#undef LZZ_INLINE
#endif
