// gram_DeclSpecFlags.cpp
//

#include "gram_DeclSpecFlags.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
