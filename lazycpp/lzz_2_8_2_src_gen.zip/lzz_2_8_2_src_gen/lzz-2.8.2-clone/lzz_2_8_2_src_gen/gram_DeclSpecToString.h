// gram_DeclSpecToString.h
//

#ifndef LZZ_gram_DeclSpecToString_h
#define LZZ_gram_DeclSpecToString_h
#define LZZ_INLINE inline
namespace gram
{
  char const * declSpecToString (int flag);
}
#undef LZZ_INLINE
#endif
