// gram_DirKind.cpp
//

#include "gram_DirKind.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
