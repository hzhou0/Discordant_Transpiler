// gram_FileStatPtr.cpp
//

#include "gram_FileStatPtr.h"
#include "gram_FileStat.h"
#include "util_BPtr.tpl"
#define LZZ_INLINE inline
template class util::BPtr <gram::FileStat>;
#undef LZZ_INLINE
