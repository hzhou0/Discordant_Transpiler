// gram_GetAccess.h
//

#ifndef LZZ_gram_GetAccess_h
#define LZZ_gram_GetAccess_h
// semantic
#include "smtc_Access.h"
#define LZZ_INLINE inline
namespace gram
{
  smtc::Access getAccess (int number);
}
#undef LZZ_INLINE
#endif
