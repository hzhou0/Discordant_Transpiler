// gram_GetClassKey.h
//

#ifndef LZZ_gram_GetClassKey_h
#define LZZ_gram_GetClassKey_h
// semantic
#include "smtc_ClassKey.h"
#define LZZ_INLINE inline
namespace gram
{
  smtc::ClassKey getClassKey (int number);
}
#undef LZZ_INLINE
#endif
