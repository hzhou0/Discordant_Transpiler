// gram_IsHexDigit.h
//

#ifndef LZZ_gram_IsHexDigit_h
#define LZZ_gram_IsHexDigit_h
#define LZZ_INLINE inline
namespace gram
{
  bool isHexDigit (char ch);
}
#undef LZZ_INLINE
#ifdef LZZ_ENABLE_INLINE
#include "gram_IsHexDigit.inl"
#endif
#endif
