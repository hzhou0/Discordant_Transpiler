// gram_IsOctalDigit.h
//

#ifndef LZZ_gram_IsOctalDigit_h
#define LZZ_gram_IsOctalDigit_h
#define LZZ_INLINE inline
namespace gram
{
  bool isOctalDigit (char ch);
}
#undef LZZ_INLINE
#endif
