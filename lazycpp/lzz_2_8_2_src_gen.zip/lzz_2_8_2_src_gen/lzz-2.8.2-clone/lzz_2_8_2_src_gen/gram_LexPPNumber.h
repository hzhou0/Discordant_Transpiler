// gram_LexPPNumber.h
//

#ifndef LZZ_gram_LexPPNumber_h
#define LZZ_gram_LexPPNumber_h
// basil
#include "basl_Token.h"
#define LZZ_INLINE inline
namespace gram
{
  void lexPPNumber (basl::Token & token);
}
#undef LZZ_INLINE
#endif
