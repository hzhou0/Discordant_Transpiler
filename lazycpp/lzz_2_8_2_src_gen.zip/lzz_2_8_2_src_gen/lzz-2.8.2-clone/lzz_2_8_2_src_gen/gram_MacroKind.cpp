// gram_MacroKind.cpp
//

#include "gram_MacroKind.h"
// gram
#define LZZ_INLINE inline
#undef LZZ_INLINE
