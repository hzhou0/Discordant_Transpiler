// gram_ReadHexDigits.h
//

#ifndef LZZ_gram_ReadHexDigits_h
#define LZZ_gram_ReadHexDigits_h
#define LZZ_INLINE inline
namespace gram
{
  int readHexDigits (char const * str, int max_num, char * out, char const * * next_char);
}
#undef LZZ_INLINE
#endif
