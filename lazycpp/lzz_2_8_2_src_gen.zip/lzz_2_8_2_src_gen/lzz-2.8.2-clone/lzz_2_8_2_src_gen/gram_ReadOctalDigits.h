// gram_ReadOctalDigits.h
//

#ifndef LZZ_gram_ReadOctalDigits_h
#define LZZ_gram_ReadOctalDigits_h
#define LZZ_INLINE inline
namespace gram
{
  int readOctalDigits (char const * str, int max_num, char * out, char const * * next_char);
}
#undef LZZ_INLINE
#endif
