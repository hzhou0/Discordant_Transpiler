// gram_TokenNumberToString.h
//

#ifndef LZZ_gram_TokenNumberToString_h
#define LZZ_gram_TokenNumberToString_h
#define LZZ_INLINE inline
namespace gram
{
  char const * tokenNumberToString (int number);
}
#undef LZZ_INLINE
#endif
