// main.h
//

#ifndef LZZ_main_h
#define LZZ_main_h
#define LZZ_INLINE inline
int main (int argc, char * * argv);
#undef LZZ_INLINE
#endif
