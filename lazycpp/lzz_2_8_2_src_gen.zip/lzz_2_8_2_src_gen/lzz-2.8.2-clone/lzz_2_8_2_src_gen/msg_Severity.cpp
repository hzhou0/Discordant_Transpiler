// msg_Severity.cpp
//

#include "msg_Severity.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
