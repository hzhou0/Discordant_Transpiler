// msg_Severity.h
//

#ifndef LZZ_msg_Severity_h
#define LZZ_msg_Severity_h
#define LZZ_INLINE inline
namespace msg
{
  enum Severity
  {
    ERROR_MSG,
    WARNING_MSG,
    INFO_MSG
  };
}
#undef LZZ_INLINE
#endif
