// smtc_AccessToString.h
//

#ifndef LZZ_smtc_AccessToString_h
#define LZZ_smtc_AccessToString_h
// semantic
#include "smtc_Access.h"
#define LZZ_INLINE inline
namespace smtc
{
  char const * accessToString (Access access);
}
#undef LZZ_INLINE
#endif
