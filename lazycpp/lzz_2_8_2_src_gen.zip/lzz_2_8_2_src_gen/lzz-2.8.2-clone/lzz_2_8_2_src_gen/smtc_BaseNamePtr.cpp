// smtc_BaseNamePtr.cpp
//

#include "smtc_BaseNamePtr.h"
#include "smtc_BaseName.h"
#include "util_BPtr.tpl"
#define LZZ_INLINE inline
template class util::BPtr <smtc::BaseName>;
#undef LZZ_INLINE
