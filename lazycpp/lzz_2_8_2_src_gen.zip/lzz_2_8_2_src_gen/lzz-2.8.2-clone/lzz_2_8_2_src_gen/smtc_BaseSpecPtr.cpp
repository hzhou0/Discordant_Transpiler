// smtc_BaseSpecPtr.cpp
//

#include "smtc_BaseSpecPtr.h"
#include "smtc_BaseSpec.h"
#include "util_BPtr.tpl"
#define LZZ_INLINE inline
template class util::BPtr <smtc::BaseSpec>;
#undef LZZ_INLINE
