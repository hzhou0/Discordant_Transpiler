// smtc_BaseSpecPtrVector.cpp
//

#include "smtc_BaseSpecPtrVector.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
