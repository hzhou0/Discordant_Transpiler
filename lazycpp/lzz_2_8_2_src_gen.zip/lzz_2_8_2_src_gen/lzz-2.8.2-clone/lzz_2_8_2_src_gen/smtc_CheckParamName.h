// smtc_CheckParamName.h
//

#ifndef LZZ_smtc_CheckParamName_h
#define LZZ_smtc_CheckParamName_h
// semantic
#include "smtc_NamePtr.h"
#define LZZ_INLINE inline
namespace smtc
{
  void checkParamName (NamePtr const & name);
}
#undef LZZ_INLINE
#endif
