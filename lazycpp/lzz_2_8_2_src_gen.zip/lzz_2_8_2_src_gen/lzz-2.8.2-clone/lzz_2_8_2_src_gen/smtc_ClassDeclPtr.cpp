// smtc_ClassDeclPtr.cpp
//

#include "smtc_ClassDeclPtr.h"
#include "smtc_ClassDecl.h"
#include "util_BPtr.tpl"
#define LZZ_INLINE inline
template class util::BPtr <smtc::ClassDecl>;
#undef LZZ_INLINE
