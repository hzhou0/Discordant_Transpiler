// smtc_ClassKey.cpp
//

#include "smtc_ClassKey.h"
#define LZZ_INLINE inline
#undef LZZ_INLINE
