// smtc_ClassKeyToString.h
//

#ifndef LZZ_smtc_ClassKeyToString_h
#define LZZ_smtc_ClassKeyToString_h
// semantic
#include "smtc_ClassKey.h"
#define LZZ_INLINE inline
namespace smtc
{
  char const * classKeyToString (ClassKey key);
}
#undef LZZ_INLINE
#endif
