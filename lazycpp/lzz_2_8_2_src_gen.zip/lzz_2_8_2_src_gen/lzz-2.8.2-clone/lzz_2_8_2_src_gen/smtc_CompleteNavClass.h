// smtc_CompleteNavClass.h
//

#ifndef LZZ_smtc_CompleteNavClass_h
#define LZZ_smtc_CompleteNavClass_h
// semantic
#include "smtc_NavClassPtr.h"
#define LZZ_INLINE inline
namespace smtc
{
  void completeNavClass (NavClassPtr const & nav_class);
}
#undef LZZ_INLINE
#endif
