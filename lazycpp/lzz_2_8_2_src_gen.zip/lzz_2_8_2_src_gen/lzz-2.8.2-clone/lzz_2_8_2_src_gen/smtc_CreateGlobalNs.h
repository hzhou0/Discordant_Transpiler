// smtc_CreateGlobalNs.h
//

#ifndef LZZ_smtc_CreateGlobalNs_h
#define LZZ_smtc_CreateGlobalNs_h
// semantic
#include "smtc_NsPtr.h"
#define LZZ_INLINE inline
namespace smtc
{
  NsPtr createGlobalNs ();
}
#undef LZZ_INLINE
#endif
