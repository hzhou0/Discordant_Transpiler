// smtc_CreateNavSubmitFuncDefnEntity.h
//

#ifndef LZZ_smtc_CreateNavSubmitFuncDefnEntity_h
#define LZZ_smtc_CreateNavSubmitFuncDefnEntity_h
// semantic
#include "smtc_EntityPtr.h"
#include "smtc_NavSubmitFuncDefnPtr.h"
#define LZZ_INLINE inline
namespace smtc
{
  EntityPtr createNavSubmitFuncDefnEntity (NavSubmitFuncDefnPtr const & nav_submit_func_defn);
}
#undef LZZ_INLINE
#endif
